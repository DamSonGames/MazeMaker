document.addEventListener("keydown", KeyDownTextField, false);

playerpos = 1;

function KeyDownTextField(e){
	keyCode = e.keyCode;
	if(keyCode == 37){
		MoveLeft();
	}else if(keyCode == 38){
		MoveUp();
	}else if(keyCode == 39){
		MoveRight();
	}else if(keyCode == 40){
		MoveDown();
	}
}

for (var i = 0; i < 141; i++) {
	eval("var type" + i + "= 0")
}

type1 = 2;
document.getElementById("Div1").style.background = "lime";

function Check(pos){
	element = "Div" + pos;
	ChangeBlock(element, pos);
}

function ChangeBlock(Div, Pos){
	if(eval("type" + Pos) == 0){
		eval("type" + Pos + "= 1");
		document.getElementById(Div).style.background = "gray";
	}else if(eval("type" + Pos) == 1){
		eval("type" + Pos + "= 0");
		document.getElementById(Div).style.background = "white";
	}else if(eval("type" + Pos) == 2){
		eval("type" + Pos + "= 0");
		document.getElementById(Div).style.background = "lime";
	}
}

function MoveLeft(){
	if(eval("type" + (playerpos - 1)) == 0){
		if((playerpos == 21) || (playerpos == 41) || (playerpos == 61) || (playerpos == 81) || (playerpos == 101) || (playerpos == 121) || (playerpos == 1)){

		}else{
			eval("type" + playerpos + "=" + "1");
			eval("type" + (playerpos - 1) + "=" + "2");
			div1 = "Div" + playerpos;
			ChangeBlock(div1, playerpos);
			playerpos -= 1;
			div2 = "Div" + playerpos;
			ChangeBlock(div2, playerpos);
		}
	}
}

function MoveRight(){
	if(eval("type" + (playerpos + 1)) == 0){
		if((playerpos == 20) || (playerpos == 40) || (playerpos == 60) || (playerpos == 80) || (playerpos == 100) || (playerpos == 120) || (playerpos == 140)){
			
		}else{
			eval("type" + playerpos + "=" + "1");
			eval("type" + (playerpos + 1) + "=" + "2");
			div1 = "Div" + playerpos;
			ChangeBlock(div1, playerpos);
			playerpos += 1;
			div2 = "Div" + playerpos;
			ChangeBlock(div2, playerpos);
		}
	}
}

function MoveUp(){
	if(eval("type" + (playerpos - 20)) == 0){
		if(playerpos <= 20){

		}else{
			eval("type" + playerpos + "=" + "1");
			eval("type" + (playerpos - 20) + "=" + "2");
			div1 = "Div" + playerpos;
			ChangeBlock(div1, playerpos);
			playerpos -= 20;
			div2 = "Div" + playerpos;
			ChangeBlock(div2, playerpos);
		}
	}
}

function MoveDown(){
	if(eval("type" + (playerpos + 20)) == 0){
		if(playerpos >= 121){

		}else{
			eval("type" + playerpos + "=" + "1");
			eval("type" + (playerpos + 20) + "=" + "2");
			div1 = "Div" + playerpos;
			ChangeBlock(div1, playerpos);
			playerpos += 20;
			div2 = "Div" + playerpos;
			ChangeBlock(div2, playerpos);
		}
	}
}